create view login_page as
select `book`.`users`.`user_phone` AS `user_phone`, `book`.`users`.`user_password` AS `user_password`
from `book`.`users`;

