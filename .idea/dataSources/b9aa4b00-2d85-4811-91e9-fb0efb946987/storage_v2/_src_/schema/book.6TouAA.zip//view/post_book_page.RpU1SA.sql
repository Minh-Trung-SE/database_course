create view post_book_page as
select `book`.`book_storage`.`book_title`     AS `Title`,
       `book`.`book_category`.`category_name` AS `Generic`,
       `book`.`book_storage`.`link_photo`     AS `Link photo`,
       `book`.`book_storage`.`price`          AS `Price`,
       `book`.`book_storage`.`release_year`   AS `Release year`,
       `book`.`book_storage`.`description`    AS `Decription`,
       `book`.`book_post`.`date`              AS `Date`,
       `book`.`book_storage`.`author`         AS `Author`
from ((`book`.`book_storage` join `book`.`book_category` on ((`book`.`book_storage`.`category_id` =
                                                              `book`.`book_category`.`category_id`)))
         join `book`.`book_post` on ((`book`.`book_storage`.`book_id` = `book`.`book_post`.`book_id`)));

