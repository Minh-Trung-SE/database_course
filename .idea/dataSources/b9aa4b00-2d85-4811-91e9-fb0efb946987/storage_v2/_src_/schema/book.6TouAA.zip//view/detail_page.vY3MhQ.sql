create view detail_page as
select `book`.`book_storage`.`link_photo`     AS `link_photo`,
       `book`.`book_storage`.`book_title`     AS `book_title`,
       `book`.`book_storage`.`release_year`   AS `release_year`,
       `book`.`book_storage`.`description`    AS `decription`,
       `book`.`book_storage`.`author`         AS `author`,
       `book`.`book_storage`.`price`          AS `price`,
       `book`.`book_category`.`category_name` AS `Generic`,
       `book`.`users`.`user_phone`            AS `user_phone`,
       `book`.`users`.`user_email`            AS `user_email`
from (((`book`.`book_storage` join `book`.`book_post` on ((`book`.`book_storage`.`book_id` = `book`.`book_post`.`book_id`))) join `book`.`users` on ((`book`.`book_post`.`user_phone` = `book`.`users`.`user_phone`)))
         join `book`.`book_category` on ((`book`.`book_storage`.`category_id` = `book`.`book_category`.`category_id`)));

