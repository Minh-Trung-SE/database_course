create view user_page_1 as
select `book`.`users`.`user_phone`    AS `user_phone`,
       `book`.`users`.`user_email`    AS `user_email`,
       `book`.`users`.`user_password` AS `user_password`
from `book`.`users`;

